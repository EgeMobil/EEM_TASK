#include <stdio.h>
#include "inc/battery_management_public.h"

int main() {
    printf("Battery Charge: %.2f%%\n", Battery_getChargeLevel());
    printf("Battery Voltage: %.2fV\n", Battery_getVoltage());
    printf("Battery Health: %s\n", Battery_getHealthStatus());
    return 0;
}
