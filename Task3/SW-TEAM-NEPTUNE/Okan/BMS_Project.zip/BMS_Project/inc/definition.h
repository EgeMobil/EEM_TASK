#ifndef DEFINITION_H
#define DEFINITION_H

#define MAX_VOLTAGE 4.2  // Maksimum hücre voltajı (V)
#define MIN_VOLTAGE 3.0  // Minimum hücre voltajı (V)
#define MAX_TEMPERATURE 60  // Maksimum sıcaklık (°C)
#define MIN_TEMPERATURE 0   // Minimum sıcaklık (°C)
#define BALANCE_THRESHOLD 0.05 // Hücre dengeleme eşiği (V)

#endif // DEFINITION_H
