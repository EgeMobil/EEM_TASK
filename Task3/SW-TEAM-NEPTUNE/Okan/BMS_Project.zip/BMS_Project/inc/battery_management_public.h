#ifndef BATTERY_MANAGEMENT_PUBLIC_H
#define BATTERY_MANAGEMENT_PUBLIC_H

#include "definition.h"

float Battery_getChargeLevel(void); // Batarya şarj seviyesi (%)
float Battery_getVoltage(void); // Batarya voltajı (V)
const char* Battery_getHealthStatus(void); // Batarya sağlık durumu

#endif // BATTERY_MANAGEMENT_PUBLIC_H
