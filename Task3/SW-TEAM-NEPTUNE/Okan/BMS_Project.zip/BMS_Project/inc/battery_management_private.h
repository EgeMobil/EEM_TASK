#ifndef BATTERY_MANAGEMENT_PRIVATE_H
#define BATTERY_MANAGEMENT_PRIVATE_H

#include "definition.h"

// Hücre bazlı sıcaklıklar ve voltaj değerleri
static float cell_temperatures[4]; // 4 hücre için sıcaklıklar
static float cell_voltages[4]; // 4 hücre için voltajlar

// Batarya dengeleme fonksiyonu (dışarıya açık değil)
static void BalanceCells(void);
// Batarya durumu analiz fonksiyonu (dışarıya açık değil)
static void AnalyzeBatteryHealth(void);

#endif // BATTERY_MANAGEMENT_PRIVATE_H
